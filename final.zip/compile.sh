g++ code.cpp -o code
g++ decode.cpp -o decode

g++ code2.cpp -o code2