#!/bin/bash

./code2 $1