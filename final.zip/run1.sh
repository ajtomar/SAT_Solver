#!/bin/bash

./code $1