#!/bin/bash

./decode $1